package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Aumotation {
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();  //-Chrome web driver - server //
	     ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
     	WebDriver driver=new ChromeDriver(options);  // ---Browser Launch-- //
	
     	String baseurl=("https://www.browserstack.com/users/sign_in"); //-- url for testing
		driver.get(baseurl); //--   for retrieve the data given in url
		driver.manage().window().maximize();   //--  to maximize the chrome window
	
		// --  used sendkeys method and click with the help of WebElement class
		WebElement email = driver.findElement(By.id("user_email_login")); //-  object for email id
		WebElement password = driver.findElement(By.id("user_password"));  //-  object for password
		WebElement login=driver.findElement(By.id("user_submit"));  //-  object for login
		
		email.sendKeys("it@reckersautomation.com");    // -  calling methods through object 
		password.sendKeys("kapil940@");
		login.click();
		System.out.println("Signed in with click");
		driver.close();
		
		
	}

}

package demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Wait {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");

		WebDriver driver = new ChromeDriver(options);
		driver.get("https://www.vuse.com/gb/en/");
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); // Implicit wait it use one time
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(3)); // PageLoad wait to test page loading time

		WebElement accept = driver.findElement(By.xpath("//button[@id='onetrust-accept-btn-handler']"));

		accept.click();

		WebElement over = driver.findElement(By.xpath("//button[@id='btn-entry-age-allow']"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1)); // Emplicity wait it use on condition
																				// basis

		// wait.until(ExpectedConditions.elementToBeClickable(over));
		wait.until(ExpectedConditions.visibilityOf(over));

		over.click();

		// WebElement search= driver.findElement(By.xpath("//input[@id='search']"));
		// search.sendKeys("mobile");
		WebElement account = driver.findElement(By.xpath("//span[@class='icon-account']"));
		// Actions a=new Actions(driver);

	}

}

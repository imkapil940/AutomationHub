package demo;

import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Multiplewindow {
         public static void main(String[] args)
         {
        	 WebDriverManager.chromedriver().setup();
     		
     		ChromeOptions options = new ChromeOptions();
     		options.addArguments("--remote-allow-origins=*");
        	WebDriver driver= new ChromeDriver(options);
        	driver.get("https://www.hyrtutorials.com/p/window-handles-practice.html");
        	driver.manage().window().maximize();
        	
       WebElement multiwindow= 	driver.findElement(By.xpath("//button[@id='newTabsBtn']"));
       multiwindow.click();
       
     String parentid=  driver.getWindowHandle();
     System.out.println(parentid); 
    Set<String>childid = driver.getWindowHandles();
     for(String window:childid)
     {
    	 if(!parentid.equals(window));
    	 System.out.println(window);
    	 driver.switchTo().window(window);
         String pagetitle=  driver.getTitle();
         if(pagetitle.contains("AlertsDemo"))
         {
       WebElement clic= 	driver.findElement(By.xpath("//button[@id='alertBox']"));
        	clic.click();
        	Alert a= driver.switchTo().alert();
        	a.accept();
        	break;
         }
         }	
        	
         }
}

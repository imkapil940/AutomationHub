package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Automation1 {
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup(); // ChromeDriver--Server
		 
		  
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(options);//------Browser Launch
	 	
		String baseurl=("https://www.vuse.com/gb/en/customer/account/create/");
		driver.get(baseurl);
		driver.manage().window().maximize();
	
		
	WebElement accept=driver.findElement(By.xpath("//button[@id='onetrust-accept-btn-handler']"));
	WebElement over=driver.findElement(By.xpath("//button[@id='btn-entry-age-allow']"));
	WebElement firstname=driver.findElement(By.xpath("//input[@id='firstname']"));
	WebElement lastname=driver.findElement(By.xpath("//input[@id='lastname']"));
	
	WebElement email=driver.findElement(By.xpath("//input[@id='email_address']"));
	WebElement date=driver.findElement(By.xpath("//input[@id='dob']"));
	WebElement gender=driver.findElement(By.xpath("//select[@id='gender']"));
	WebElement manualclick_address=driver.findElement(By.xpath("//div[@class='address-manual-button']"));
	WebElement street_address=driver.findElement(By.xpath("//input[@id='street_1']"));
	WebElement street2_address=driver.findElement(By.xpath("//input[@id='street_2']"));
	//WebElement street3_address=driver.findElement(By.xpath("//input[@id='street_3']"));
	WebElement city_address=driver.findElement(By.xpath("//input[@id='city']"));
	//WebElement state_address=driver.findElement(By.xpath("//input[@id='region']"));
	WebElement zip_address=driver.findElement(By.xpath("//input[@id='zip']"));
	WebElement country_address=driver.findElement(By.xpath("//select[@id='country']"));
	
   // WebElement address=driver.findElement(By.xpath("//div[@class='pcaitem pcalastitem pcaselected']"));
//	WebElement mobile=driver.findElement(By.xpath("//input[@id='telephone']"));
	WebElement not_mobile=driver.findElement(By.xpath("//label[@for='mobile_text_required']"));;
	WebElement password=driver.findElement(By.xpath("//input[@id='password']"));
	WebElement confirm_password=driver.findElement(By.xpath("//input[@id='password-confirmation']"));
	WebElement accept_password=driver.findElement(By.xpath("//label[@for='agreement-1']"));
	WebElement email_marketing=driver.findElement(By.xpath("//label[@for='email_marketing']"));
//	WebElement rebot=driver.findElement(By.xpath("//label[@id='recaptcha-anchor-label']"));
	WebElement create_your_account=driver.findElement(By.xpath("//button[@title='Create Your Account']"));
	
	//WebElement email_confirm=driver.findElement(By.xpath("//input[@name='login[username]']"));
	//WebElement password_save=driver.findElement(By.xpath("//input[@id='pass']"));
	//WebElement sighnin=driver.findElement(By.xpath("//button[@id='send2']"));
	
	
//	WebElement email=driver.findElement(By.xpath("//input[@name='login[username]']"));
//	WebElement password=driver.findElement(By.xpath("//input[@name='login[password]']"));
//	WebElement  submit=driver.findElement(By.xpath("//button[@type='submit']"));
	
//	String gmailid="kapil34@gmail.com";
	accept.click();
	over.click();
	firstname.sendKeys("Kapil");
	lastname.sendKeys("Sharma");
	email.sendKeys("kapil34@gmail.com");
	date.sendKeys("02/06/1998");
	gender.sendKeys("Male");
	manualclick_address.click();
	street_address.sendKeys("Meerut House, Norwich Road");
	street2_address.sendKeys("Earl Stonham");
	//street3_address.sendKeys("chhur");
	city_address.sendKeys("Stowmarket");
//	state_address.sendKeys("up");
	zip_address.sendKeys("IP14 5DW");
	country_address.sendKeys("United Kingdom");
	
//	address.click();
//	mobile.sendKeys("9205182911");
	not_mobile.click();
	password.sendKeys("Kapil940@");
	confirm_password.sendKeys("Kapil940@");
	accept_password.click();
	email_marketing.click();
//	rebot.click();
    create_your_account.click();
    
  //  email_confirm.sendKeys("kapil34@gmail.com");
  //  password_save.sendKeys("Kapil940@");
  //  sighnin.clear();
    
//	email.sendKeys("kapil@gmail.com");
//	password.sendKeys("kapil940");
//	submit.click();
		
		
	}

}

package demo;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Windowhandling {
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		WebDriver driver= new ChromeDriver(options);
		driver.get("https://www.hyrtutorials.com/p/window-handles-practice.html");
		driver.manage().window().maximize();
		
		
	WebElement windowhandeling =	driver.findElement(By.xpath("//button[@id='newWindowBtn']"));
	windowhandeling.click();
	
    String parentid=	driver.getWindowHandle();  //  find parent window id
    System.out.println(parentid);
    
    Set<String>childid =  driver.getWindowHandles();  // find multiple windowid (parent+child all)
    for(String window:childid)
    {
    	if(!parentid.equals(window))
    	{
    		driver.switchTo().window(window);
    	}
    }
    
   WebElement lastname= driver.findElement(By.xpath("//input[@id='lastName']"));
   lastname.sendKeys("sharma");
	  
       driver.close();
       driver.switchTo().window(parentid);
       
      WebElement text= driver.findElement(By.xpath("//input[@id='name']"));
        text.sendKeys("kapil");	
  
   
	 
	}

}

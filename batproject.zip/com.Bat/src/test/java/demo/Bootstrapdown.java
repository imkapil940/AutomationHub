package demo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Bootstrapdown {
	
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		WebDriver driver= new ChromeDriver(options);
		driver.get("https://seleniumpractise.blogspot.com/2016/08/bootstrap-dropdown-example-for-selenium.html");
		driver.manage().window().maximize();
		
		
	WebElement dropdown=	driver.findElement(By.xpath("//button[@id='menu1']"));	
	
	dropdown.click();
	
	       List<WebElement> dropdownlist= driver.findElements(By.xpath("//ul[@class='dropdown-menu']/li/a"));
	       
	      int size= dropdownlist.size();
	      
	     System.out.println(size);
	     
	     // --loop   for each
	     
	     for ( WebElement selectitem : dropdownlist)
	     {
	    	String value = selectitem.getText();
	    	
	    	if (value.equals("JavaScript"))
	    	{
	    		selectitem.click();
	    		break;
	    	}
	    	 
	    	 
	     }
	       
	       
	       
	
	}

	
	
	
	
}

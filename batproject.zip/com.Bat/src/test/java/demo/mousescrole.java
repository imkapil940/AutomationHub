package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class mousescrole {
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		WebDriver driver= new ChromeDriver(options);
		driver.get("https://www.browserstack.com/?utm_source=google&utm_medium=cpc&utm_platform=paidads&utm_content=609922405122&utm_campaign=Search-Brand-India&utm_campaigncode=BrowserStack-Alpha+9303888&utm_term=e+browserstack&gclid=Cj0KCQjwla-hBhD7ARIsAM9tQKvJi4yMqFHyIem1Jyo4Cu1tgbh1cU7sl7ZALL3WP_ykAFCSkl3lQMkaAsVHEALw_wcB");
		driver.manage().window().maximize();
		
//	WebElement scrole=	driver.findElement(By.xpath("//button[@id='product-menu-toggle']"));
		
		
	//	a.doubleClick(scrole);
	//	a.contextClick(scrole);
	//	a.click(scrole);
	//	a.moveToElement(scrole);
		
		//  Keyboard Enter button
		
	 WebElement search=	driver.findElement(By.xpath("//button[@class='doc-search-menu dropdown-toggle doc-search-cta doc-search-menu-icon doc-menu-toggle']"));
	 search.click();
	
     WebElement enter= driver.findElement(By.xpath("//input[@id='doc-search-box-input']"));
     enter.sendKeys("test");
     
     Actions a=new Actions(driver);
     
     a.sendKeys(Keys.ENTER).build().perform();
     
	}

}

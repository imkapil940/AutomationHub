package demo;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Flipkart {
	     public static void main(String[] args)
	     {
	    	 WebDriverManager.chromedriver().setup();
	    	 
	    	 ChromeOptions options = new ChromeOptions();
	 		options.addArguments("--remote-allow-origins=*");
	    	 WebDriver driver=new ChromeDriver(options);
	    	 driver.get("https://www.flipkart.com/");
	    	 
	    	 driver.manage().window().maximize();
	    	 
	    WebElement cross=	 driver.findElement(By.xpath("//button[@class='_2KpZ6l _2doB4z']"));
	    cross.click();
	    
	    WebElement search= driver.findElement(By.xpath("//input[@class='_3704LK']"));
	    search.sendKeys("apple 13 pro");
	    Actions a=new Actions(driver);
	   a.sendKeys(Keys.ENTER).build().perform();
	   
	 //div[@class='col col-7-12']
	 //img[@alt='APPLE iPhone 13 Pro (Silver, 512 GB)']
	   
	WebElement apple13= driver.findElement(By.xpath("//div[@class='col col-7-12']"));
	    	 apple13.click();
	    	
    String parentwindowid=	driver.getWindowHandle();
	    
	   Set<String>childwindowid= driver.getWindowHandles();
	   
	   for(String window:childwindowid)
	   {
		   if(!parentwindowid.equals(window))
		   {
			   driver.switchTo().window(window);
			   break;
		   }
	     }
	    	 
	     }

}

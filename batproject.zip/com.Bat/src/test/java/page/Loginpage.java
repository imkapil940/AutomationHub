package page;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import base.Base;
import io.cucumber.java.After;
//import base.Base;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Loginpage extends Base
    {
	
	//WebDriver driver;
	
	
	
	public void user_launch_site_url() {
		// Write code here that turns the phrase above into concrete actions
	   //	setup();
		

	}
	public void user_enter_correct_user_and_password(String uname,String passw) 
	{
		// Write code here that turns the phrase above into concrete actions
		WebElement user = driver.findElement(By.xpath("//input[@id='user-name']"));
		user.sendKeys(uname);
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		password.sendKeys(passw);
		// screenshot();
		
		
	}
	public void user_click_on_loin_button() 
	{
		// Write code here that turns the phrase above into concrete actions
		WebElement login = driver.findElement(By.xpath("//input[@id='login-button']"));
    	//login.click();
		mouseaction(login);
		
			}
	
	public void validate_user_navigateto_home_page() {
		
		assertTrue(driver.findElement(By.xpath("//span[@class='title']")).isDisplayed());
	}
}

package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {

	public static WebDriver driver;
	public static Properties prop;
	static {
		try {
			FileInputStream fis = new FileInputStream("TestData/TestData.properties");
			prop = new Properties();
			prop.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void setup() {
		// Write code here that turns the phrase above into concrete actions

		String Browsername = prop.getProperty("browser");
		if (Browsername.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--incognito");
			options.addArguments("--remote-allow-origins=*");
			driver = new ChromeDriver(options);
		} else if (Browsername.equals("firfox")) {
			WebDriverManager.firefoxdriver().setup();
			FirefoxOptions options = new FirefoxOptions();
			options.addArguments("--incognito");
			driver = new FirefoxDriver(options);
		} else if (Browsername.equals("edge")) {
			WebDriverManager.edgedriver().setup();
			EdgeOptions options = new EdgeOptions();
			options.addArguments("--incognito");
			options.addArguments("--remote-allow-origins=*");
			driver = new EdgeDriver(options);

		}

		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(5));

	}

	public void mouseaction(WebElement mouse) {
		Actions a = new Actions(driver);
		// a.moveToElement(mouse).build().perform();
		a.click(mouse).build().perform();
	}
	public void enterkeyaction(WebElement enter) {
		Actions a = new Actions(driver);
		a.sendKeys(Keys.ENTER).build().perform();
	}
	public void selectvisibledropdown(WebElement sd, String value) {
		Select s = new Select(sd);
		s.selectByVisibleText(value);
	}
	public void selectindexdropdown(WebElement sd, int value) {
		Select s = new Select(sd);
		s.selectByIndex(value);
	}
	public void javaexecutorclick(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element);
	}
	public void ExplicitwaitvisibilityS(WebElement EW, int timeout) {
		WebDriverWait wait=new WebDriverWait (driver, Duration.ofSeconds(timeout));
		wait.until(ExpectedConditions.visibilityOf(EW));
	}
	public void screenshot() {
		TakesScreenshot ts=(TakesScreenshot)driver;
		 File Scrfile=   ts.getScreenshotAs(OutputType.FILE);
		 try {
			FileUtils.copyFile(Scrfile, new File ("screenshot/"+System.currentTimeMillis()+".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}
	
}
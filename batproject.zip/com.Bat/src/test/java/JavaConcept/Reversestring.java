package JavaConcept;

public class Reversestring {
	
	public static void main(String[] args) {
		
		String s="Automation Test";
	// reverse program
		String rev="";
		
//		int len=s.length();
//		
//		 for(int i=len-1;i>=0;i--) {
//			rev = rev+s.charAt(i);
//			  
//		 }
//		 System.out.println(rev);  
	
		
		
	    String[]t=	s.split(" ");
	    int l=t.length;
	    
	    for(int i=l-1;i>=0;i--) {
	    	rev= rev+" "+t[i];
	    }
	    System.out.println(rev); 
	
	
	}
	
	

}

package JavaConcept;

public class Methodsoverloading {

	
	public void  test() {
		
	}
	
	public void test(int i) {
		
	}
	
	public void test(int i,int j) {
		
	}
}
// In any class methods is same but arguments is diffrents is known as Methods overloading

//  A methods is in parents class and after extends that class in child class we have 
//  created same name new methods is know as OverRiding
package JavaConcept;

public class SBI implements Test{

	@Override
	public void homeloan() {
		// TODO Auto-generated method stub
		System.out.println("19%");	
	}

	@Override
	public void carloan() {
		// TODO Auto-generated method stub
		System.out.println("20%");
		
	}

	@Override
	public void landloan() {
		// TODO Auto-generated method stub
		System.out.println("21%");
		
	}
	
	

}

package JavaConcept;

public abstract class Demoabstract {
	
	public abstract void m1();
	
	public void test() {
		
	}
	public void test1() {
		
	}
	public abstract void m2();

}
//  the methods which is created with abstract keyword then it is compailsary to take that methods when
//  extends the class
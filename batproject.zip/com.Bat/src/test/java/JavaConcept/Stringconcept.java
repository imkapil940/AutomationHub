package JavaConcept;

public class Stringconcept {
	public static void main (String[] args) {
		String s="Automation";
		String s1="automation";
		int i=s.length();
		
		System.out.println(i);
		  boolean result=s.equals(s1); // writen type boolen
		  System.out.println(result);
		  System.out.println(s.equalsIgnoreCase(s1));
		//  String s2=s.toUpperCase();
		  String s2=s.toLowerCase();
		  System.out.println(s2);
		  
		 char c= s.charAt(3);
		 System.out.println(c);
		 System.out.println(s.concat(s1));  //  concat methods
		 System.out.println(s+s1);
	}

}

package JavaConcept;

import java.util.ArrayList;
import java.util.List;

public class Listconcept {
	public static void main (String[] args) {
	
	List<String> l= new  ArrayList<String>();
	l.add("kapil");  //index 0
	l.add("dev");    //index 1
	l.add("sharma");   //index 2
	l.add("kapil");     //index 3
	
	System .out.println(l);
	System .out.println(l.get(1));
	
	int len=l.size();
	
	System .out.println(len);
	
	for(int i=0;i<len;i++) {
		System .out.println(l.get(i));
		
	}
	
	
	
	
	}

}

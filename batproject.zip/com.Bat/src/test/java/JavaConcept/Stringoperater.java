package JavaConcept;

public class Stringoperater {
	
	public static void main(String[] args) {
		
		
		String s="Automation";
		String s1="Test";
		
		int i=10;
		int j=20;
		
		System.out.println(s+s1+i+j);
		System.out.println(i+j+s+s1);
		System.out.println(s+s1+(i+j));
		System.out.println(s+s1+i*j);
	}

}

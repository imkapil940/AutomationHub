package JavaConcept;

public interface Test {
	
	public void homeloan();
	public void carloan();
	public void landloan();

}

package JavaConcept;

public class Stringjunkvalue {
	
	public static void main(String[] args) {
		String s="testautomation#$#%&#*guycdgc  2135646";
		
	String value=	s.replaceAll("[^a-zA-Z0-9]","");
	
	System.out.println(value);
	}

}

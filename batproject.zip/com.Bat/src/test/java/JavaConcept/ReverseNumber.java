package JavaConcept;

public class ReverseNumber {
	
	public static void main(String[] args) {
	
	int num=12345;
	int rev=0;
	
	while (num!=0) {   //  while loop work till its condition is true
		
		int rem=num%10;  // 1
		rev=rev*10+rem;  //54321
		num=num/10;  //1
		
	}
	System.out.println(rev);
	
	}

}

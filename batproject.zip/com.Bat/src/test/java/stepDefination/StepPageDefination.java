package stepDefination;

import base.Base;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import page.Loginpage;

public class StepPageDefination  {

	Loginpage login = new Loginpage();
	// Base base=new Base();

	@Given("User launch site URL")
	public void user_launch_site_url() {
		//setup();
	//	login.user_launch_site_url();

	}

//	@When("User enter correct user and password")
//	public void user_enter_correct_user_and_password() {
//	//	login.user_enter_correct_user_and_password();
//
//	}
	
	@When("User enter correct (String) and (string)")
	public void user_enter_correct_and(String uname,String passw) {
		login.user_enter_correct_user_and_password(uname, passw);

	}


	@When("user click on loin button")
	public void user_click_on_loin_button() {
		login.user_click_on_loin_button();

	}

	@Then("Validate user navigateto home page")
	public void validate_user_navigateto_home_page() {
		// Write code here that turns the phrase above into concrete actions
		login.validate_user_navigateto_home_page();

	}

}
